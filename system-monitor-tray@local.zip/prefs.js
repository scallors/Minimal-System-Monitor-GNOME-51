// System Monitor Tray — preferences (choose the order of CPU / RAM / temperature)

import Adw from 'gi://Adw';
import Gtk from 'gi://Gtk';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

const DEFAULT_ORDER = ['cpu', 'ram', 'temp'];
const NAMES = {
    cpu: 'CPU usage',
    ram: 'RAM usage',
    temp: 'CPU temperature',
};

// Keep only known items, once each, and add any that are missing
function sanitizeOrder(order) {
    const result = order.filter((id, i) => DEFAULT_ORDER.includes(id) && order.indexOf(id) === i);
    for (const id of DEFAULT_ORDER) {
        if (!result.includes(id))
            result.push(id);
    }
    return result;
}

export default class SystemMonitorTrayPrefs extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();

        const page = new Adw.PreferencesPage({
            title: 'General',
            icon_name: 'preferences-system-symbolic',
        });
        const group = new Adw.PreferencesGroup({
            title: 'Order',
            description: 'Use the arrows to choose the order of the readings in the system tray. ' +
                         'The top item is shown leftmost.',
        });
        page.add(group);
        window.add(page);

        let rows = [];

        const move = (index, delta) => {
            const order = sanitizeOrder(settings.get_strv('order'));
            const target = index + delta;
            if (target < 0 || target >= order.length)
                return;
            [order[index], order[target]] = [order[target], order[index]];
            settings.set_strv('order', order);
        };

        const rebuild = () => {
            for (const row of rows)
                group.remove(row);
            rows = [];

            const order = sanitizeOrder(settings.get_strv('order'));
            order.forEach((id, i) => {
                const row = new Adw.ActionRow({
                    title: NAMES[id],
                    subtitle: `Position ${i + 1}`,
                });

                const up = new Gtk.Button({
                    icon_name: 'go-up-symbolic',
                    valign: Gtk.Align.CENTER,
                    css_classes: ['flat'],
                    sensitive: i > 0,
                    tooltip_text: 'Move left',
                });
                up.connect('clicked', () => move(i, -1));

                const down = new Gtk.Button({
                    icon_name: 'go-down-symbolic',
                    valign: Gtk.Align.CENTER,
                    css_classes: ['flat'],
                    sensitive: i < order.length - 1,
                    tooltip_text: 'Move right',
                });
                down.connect('clicked', () => move(i, 1));

                row.add_suffix(up);
                row.add_suffix(down);
                group.add(row);
                rows.push(row);
            });
        };

        const changedId = settings.connect('changed::order', rebuild);
        window.connect('close-request', () => {
            settings.disconnect(changedId);
            return false;
        });

        rebuild();
    }
}
