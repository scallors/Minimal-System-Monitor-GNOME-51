// System Monitor Tray — GNOME Shell 51
// CPU %, RAM % and CPU temperature, shown inside the system tray group
// (the Wi-Fi / volume / battery pill) in the top-right corner.

import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import St from 'gi://St';

import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {SystemIndicator} from 'resource:///org/gnome/shell/ui/quickSettings.js';

const UPDATE_INTERVAL_SECONDS = 1;
const HOT_TEMP_C = 85;   // temperature label turns red above this

const decoder = new TextDecoder();

function readText(path) {
    try {
        const [ok, bytes] = GLib.file_get_contents(path);
        return ok ? decoder.decode(bytes).trim() : null;
    } catch (e) {
        return null;
    }
}

function listDir(path) {
    const names = [];
    try {
        const dir = GLib.Dir.open(path, 0);
        let name;
        while ((name = dir.read_name()) !== null)
            names.push(name);
        dir.close();
    } catch (e) {
        // missing directory
    }
    return names;
}

// --- CPU usage: /proc/stat deltas -------------------------------------------
function readCpuTimes() {
    const text = readText('/proc/stat');
    if (!text)
        return null;
    // "cpu  user nice system idle iowait irq softirq steal guest guest_nice"
    const fields = text.split('\n')[0].trim().split(/\s+/).slice(1, 9).map(Number);
    if (fields.length < 8 || fields.some(Number.isNaN))
        return null;
    return {
        idle: fields[3] + fields[4],                 // idle + iowait
        total: fields.reduce((a, b) => a + b, 0),
    };
}

// --- RAM usage: /proc/meminfo -----------------------------------------------
function readRamPercent() {
    const text = readText('/proc/meminfo');
    if (!text)
        return null;
    const total = /MemTotal:\s+(\d+)/.exec(text);
    const available = /MemAvailable:\s+(\d+)/.exec(text);
    if (!total || !available)
        return null;
    return 100 * (1 - Number(available[1]) / Number(total[1]));
}

// --- CPU temperature: find the right sensor once ----------------------------
// Intel: coretemp ("Package id 0"), AMD: k10temp / zenpower ("Tctl"/"Tdie"),
// ARM: cpu_thermal. Falls back to the x86_pkg_temp thermal zone.
function findTempSensor() {
    const preferred = ['coretemp', 'k10temp', 'zenpower', 'cpu_thermal'];
    const candidates = [];

    for (const entry of listDir('/sys/class/hwmon')) {
        const hwmon = `/sys/class/hwmon/${entry}`;
        const chip = readText(`${hwmon}/name`);
        const rank = preferred.indexOf(chip);
        if (rank < 0)
            continue;

        let best = null;
        for (let i = 1; i <= 16; i++) {
            const input = `${hwmon}/temp${i}_input`;
            if (readText(input) === null)
                continue;
            const label = readText(`${hwmon}/temp${i}_label`) ?? '';
            if (/package|tctl|tdie/i.test(label)) {
                best = input;
                break;
            }
            best ??= input;
        }
        if (best)
            candidates.push({rank, path: best});
    }

    if (candidates.length > 0) {
        candidates.sort((a, b) => a.rank - b.rank);
        return candidates[0].path;
    }

    for (const entry of listDir('/sys/class/thermal')) {
        if (!entry.startsWith('thermal_zone'))
            continue;
        const type = readText(`/sys/class/thermal/${entry}/type`) ?? '';
        if (/x86_pkg_temp|cpu/i.test(type))
            return `/sys/class/thermal/${entry}/temp`;
    }
    return null;
}

function readTempC(path) {
    const text = readText(path);
    const value = text === null ? NaN : parseInt(text, 10);
    return Number.isNaN(value) ? null : value / 1000;   // sysfs gives millidegrees
}

// --- the extension -----------------------------------------------------------
export default class SystemMonitorTray extends Extension {
    enable() {
        this._prevCpu = readCpuTimes();
        this._tempPath = findTempSensor();

        this._cpuLabel = this._makeLabel('sysmon-cpu', 'CPU --%');
        this._ramLabel = this._makeLabel('sysmon-ram', 'RAM --%');
        this._tempLabel = this._makeLabel('sysmon-temp', '--°C');
        this._tempLabel.visible = this._tempPath !== null;   // hide if no sensor was found

        // Labels live inside a SystemIndicator, which goes into the system tray pill.
        this._indicator = new SystemIndicator();
        this._indicator.add_child(this._cpuLabel);
        this._indicator.add_child(this._ramLabel);
        this._indicator.add_child(this._tempLabel);
        this._indicator.visible = true;

        Main.panel.statusArea.quickSettings.addExternalIndicator(this._indicator);

        // Put it first (leftmost) in the group
        this._indicator.get_parent()?.set_child_at_index(this._indicator, 0);

        this._timeoutId = GLib.timeout_add_seconds(
            GLib.PRIORITY_DEFAULT, UPDATE_INTERVAL_SECONDS, () => {
                this._update();
                return GLib.SOURCE_CONTINUE;
            });
        this._update();
    }

    // Must stay synchronous — GNOME 51 throws if disable() is async.
    disable() {
        if (this._timeoutId) {
            GLib.source_remove(this._timeoutId);
            this._timeoutId = 0;
        }
        this._indicator?.destroy();
        this._indicator = null;
        this._cpuLabel = this._ramLabel = this._tempLabel = null;
        this._prevCpu = null;
    }

    _makeLabel(styleClass, text) {
        return new St.Label({
            text,
            style_class: `sysmon-label ${styleClass}`,
            y_align: Clutter.ActorAlign.CENTER,
        });
    }

    _update() {
        // CPU
        const cpu = readCpuTimes();
        if (cpu && this._prevCpu) {
            const total = cpu.total - this._prevCpu.total;
            const idle = cpu.idle - this._prevCpu.idle;
            if (total > 0) {
                const pct = Math.min(100, Math.max(0, Math.round(100 * (1 - idle / total))));
                this._cpuLabel.text = `CPU ${pct}%`;
            }
        }
        this._prevCpu = cpu;

        // RAM
        const ram = readRamPercent();
        if (ram !== null)
            this._ramLabel.text = `RAM ${Math.round(ram)}%`;

        // Temperature
        if (this._tempPath) {
            const temp = readTempC(this._tempPath);
            if (temp !== null) {
                this._tempLabel.text = `${Math.round(temp)}°C`;
                if (temp >= HOT_TEMP_C)
                    this._tempLabel.add_style_class_name('sysmon-hot');
                else
                    this._tempLabel.remove_style_class_name('sysmon-hot');
            }
        }
    }
}
